CREATE TABLE `users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(50) NOT NULL,
  `passwd` varchar(50) NOT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
ALTER TABLE `users` AUTO_INCREMENT=1;

CREATE TABLE `goods` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `img` varchar(200) NOT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
ALTER TABLE `goods` AUTO_INCREMENT=1;

CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(100) NOT NULL,
  `gid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
ALTER TABLE `info` AUTO_INCREMENT=1;
