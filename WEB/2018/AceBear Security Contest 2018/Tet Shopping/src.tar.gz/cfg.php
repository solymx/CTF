<?php

class Jdb{
	private $db_server = "localhost";
	private $db_user = "xxxx";
	private $db_pass = 'xxxx';
	private $db_database = "xxxx";
	private $conn;
	function __construct(){
		$this->conn = mysqli_connect($this->db_server, $this->db_user, $this->db_pass, $this->db_database);
		if (mysqli_connect_errno())
  			die("Cannot connect database");
  		mysqli_query($this->conn, "SET sql_mode=ANSI");
	}
	function fetch_assoc($qr){
		$qq = mysqli_query($this->conn, $qr);
		
		$return = array();
		while($req = mysqli_fetch_assoc($qq)){
			array_push($return, $req);
		}
		return $return;
	}
	
	function insert_data($qr){
		return mysqli_query($this->conn, $qr);
	}

	function addParameter($qr, $args){
		if(is_null($qr)){
			return;
		}
		if(strpos($qr, '%') === false ) {
			return;
		}
		$args = func_get_args();
		array_shift($args);
		if(is_array($args[0]) && count($args)==1){
			$args = $args[0];
		}
		foreach($args as $arg){
			if(!is_scalar($arg) && !is_null($arg)){

				return;
			}
		}
		$qr = str_replace( "'%s'", '%s', $qr); 
		$qr = str_replace( '"%s"', '%s', $qr); 
		$qr = preg_replace( '|(?<!%)%f|' , '%F', $qr);
		$qr = preg_replace( '|(?<!%)%s|', "'%s'", $qr); 

		array_walk($args, array( $this, 'ebr' ) );
		return @vsprintf($qr, $args);

	}
	function ebr(&$st ) {
		if (!is_float($st))
			$st = $this->_re($st);
	}
	function _re($st) {
		if ($this->conn) {
			return mysqli_real_escape_string($this->conn, $st);
		}
		
		return addslashes($st);
	}

}
$jdb = new Jdb();

include "func.php";
