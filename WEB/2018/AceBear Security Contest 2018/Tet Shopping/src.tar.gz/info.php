<?php
session_start();
include 'cfg.php';

if(!isLogin())
	die(header("Location: login.php"));
if(!isset($_GET['uid']))
	die("Aha...");

$uid = (int)$_SESSION["id"];
$prepare_qr = $jdb->addParameter("SELECT user from users where uid=%s", $uid);
$result1 = $jdb->fetch_assoc($prepare_qr);
$username = $result1[0]['user'];

$prepare_qr = $jdb->addParameter("SELECT goods.name, goods.description, goods.img from goods inner join info on goods.uid=info.gid where gid=%s",  $_GET['uid']);
$prepare_qr = $jdb->addParameter($prepare_qr.' and user=%s', $username);

$result = $jdb->fetch_assoc($prepare_qr);

if(count($result)<=0)
	die("Not yet!");


echo '<title>Verified: '.$result[0]['name'].'</title>';
echo 'Product Name: '.$result[0]['name'].'<br>';
echo 'Product Description: '.$result[0]['description'].'<br>';
echo '<b>This product has been verified by Pepe and safe for using!</b><br>';
echo '<img height="300px" weight="300px" src="data:image/png;base64,'.watermark_me($result[0]['img']).'"><br>';
