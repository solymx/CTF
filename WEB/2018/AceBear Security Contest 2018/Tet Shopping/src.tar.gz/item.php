<?php
session_start();
include 'cfg.php';
if(!isLogin())
	die(header("Location: login.php"));
if(!isset($_GET['uid']))
	die("Aha...");

$prepare_qr = $jdb->addParameter("SELECT * from goods where uid=%s", $_GET['uid']);
$result = $jdb->fetch_assoc($prepare_qr);
if(count($result)<=0)
	die('Not found');

$uid = (int)$_SESSION["id"];
$prepare_qr = $jdb->addParameter("SELECT user from users where uid=%s", $uid);
$result1 = $jdb->fetch_assoc($prepare_qr);
$username = $result1[0]['user'];

$prepare_qr = $jdb->addParameter("SELECT * from info where user=%s",$username);
$prepare_qr = $jdb->addParameter($prepare_qr." and gid=%s",  $_GET['uid']);
$result2 = $jdb->fetch_assoc($prepare_qr);

if(count($result2)!==0)
	die("You already own it!");
if(isset($_GET['action']) && $_GET['action']==='buy'){
	$prepare_insert = $jdb->addParameter("INSERT into info values (0, %s, %s)", $username, $_GET['uid']);
	$jdb->insert_data($prepare_insert);
	die("Buy successful!");
}
echo '<title>'.$result[0]['name'].'</title>';
echo 'Product Name: '.$result[0]['name'].'<br>';
echo 'Product Description: '.$result[0]['description'].'<br>';
echo '<img height="300px" weight="300px" src="'.$result[0]['img'].'"><br>';
echo '<a href="?action=buy&uid='.$result[0]['uid'].'">Buy without money</a>';