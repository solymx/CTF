<?php
session_start();
include 'cfg.php';
if(!isLogin())
	die(header("Location: login.php"));

$uid = (int)$_SESSION["id"];

$prepare_qr = $jdb->addParameter("SELECT user from users where uid=%s", $uid);
$result = $jdb->fetch_assoc($prepare_qr);
$username = $result[0]['user'];
echo "Hello <b>".$username."</b>, <a href='logout.php'>Logout</a><br>";

echo "Lunar new year is coming, let 's buy something for your family!<br>";
echo "<br>Choose the item you want to buy:<br>";

$prepare_qr = "SELECT uid,name from goods";
$result = $jdb->fetch_assoc($prepare_qr);

for($i=0; $i<count($result); $i++){
	echo '<a href="item.php?uid='.$result[$i]['uid'].'">'.$result[$i]['name'].'</a><br>';
}

echo "<br>Item in your bag, please check again:<br>";

$prepare_qr = $jdb->addParameter("SELECT goods.uid, goods.name from goods inner join info on goods.uid=info.gid where info.user=%s", $username);
$result = $jdb->fetch_assoc($prepare_qr);
for($i=0; $i<count($result); $i++){
	echo '<a href="info.php?uid='.$result[$i]['uid'].'">'.$result[$i]['name'].'</a><br>';
}
