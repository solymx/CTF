<?php
	session_start();
	include "cfg.php";
	if (isLogin()) 
	{
		session_destroy();
		if (isset($_COOKIE))
	    	foreach($_COOKIE as $name => $value)
	            setcookie($name, '', 1,'/');
	}
	die(header("Location: login.php"));
?>