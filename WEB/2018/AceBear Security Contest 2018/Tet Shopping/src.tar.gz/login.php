<?php
session_start();
include "cfg.php";

if (isLogin())
	die(header("Location: index.php"));
$msg = '';
if(isset($_POST['action'])){
	switch($_POST['action']){
		case 'login':
			if (isset($_POST["user"]) && !empty($_POST["user"]) && isset($_POST["passwd"]) && !empty($_POST["passwd"])) {
				$prepare_qr = $jdb->addParameter("SELECT uid from users where user=%s and passwd=sha1(%s)", $_POST["user"], $_POST['passwd']);
				$result = $jdb->fetch_assoc($prepare_qr);
				if(count($result)===1){
					$_SESSION["id"] = (int)$result[0]["uid"];
					$msg = "Login successful!";
					die(header("Location: index.php"));
				}else{
					$msg = "Invalid information!";
				}
				
			}else{
				$msg = "Missing detail!";
			}
		break;
		case 'register':
		if (isset($_POST["user"]) && !empty($_POST["user"]) && isset($_POST["passwd"]) && !empty($_POST["passwd"])){
			$prepare_qr = $jdb->addParameter("SELECT uid from users where user=%s", $_POST['user']);
			$result = $jdb->fetch_assoc($prepare_qr);
			if(count($result)>0){
				$msg = "User exists!";
			}else{
			$prepare_qr = $jdb->addParameter("INSERT INTO users VALUES (0, %s, sha1(%s))"	, $_POST["user"], $_POST["passwd"]);
			$result = $jdb->insert_data($prepare_qr);
			if($result)
				$msg = "Register successful!";
			else
				$msg = "Register failed!";
			}

		}else{
			$msg = "Missing detail!";
		}

		break;
		
	}
}
echo $msg;
?>

	<center>
	Login / Register
	<br>
	<form class="form-signin" action="login.php" method="POST">		
	<input placeholder="Username" type="text" name="user"><br>
	<input placeholder="Password" type="password" name="passwd"><br>
	<input name="action" value="login" type="submit">
	<input name="action" value="register" type="submit">
	</form>

</center>
