<?php

function isLogin() {
	return isset($_SESSION["id"]);
}
function get_data($url) {
	$ch = curl_init();
	$timeout = 2;
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	$data = curl_exec($ch);
	curl_close($ch);
	return $data;
}

function watermark_me($img){
	if(preg_match('/^file/', $img)){
		die("Ahihi");
	}
	$file_content = get_data($img);

	$fname = 'tmp-img-'.rand(0,9).'.tmp';
	file_put_contents('/tmp/'.$fname, $file_content);
	while(1){
	if(file_exists('/tmp/'.$fname))
		break;
	}

	$stamp = imagecreatefromjpeg('ok.jpg');
	$imgPng = imagecreatefromjpeg('/tmp/'.$fname);

	$marge_right = 10;
	$marge_bottom = 10;
	$sx = imagesx($stamp);
	$sy = imagesy($stamp);


	imagecopy($imgPng, $stamp, imagesx($imgPng) - $sx - $marge_right, imagesy($imgPng) - $sy - $marge_bottom, 0, 0, imagesx($stamp), imagesy($stamp));

	if($imgPng){
		@unlink('/tmp/'.$fname);
		//header("Content-type: image/png");
		ob_start();
		imagePng($imgPng); 
		$imagedata = base64_encode(ob_get_contents());

		ob_end_clean();
		@imagedestroy($imgPng);
		return $imagedata;
	}else{
		@unlink('/tmp/'.$fname);
		die("Ahihi");
	}
}
