./qemu/microblazeel-softmmu/qemu-system-microblazeel  -m 256 -serial mon:stdio -display none  -kernel linux.bin -initrd initrd.image.gz -nographic -M petalogix-s3adsp1800 -net nic -net tap,ifname=tap0,script=no

