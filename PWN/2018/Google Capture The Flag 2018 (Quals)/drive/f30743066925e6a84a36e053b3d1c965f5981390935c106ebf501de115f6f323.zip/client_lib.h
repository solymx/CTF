#include <stdlib.h>
void write_shared_file(char *filename, char *content, size_t content_len);
int read_shared_file(char *filename);
